# Adversarial ToM-RL

A robust reinforcement learning framework for autonomous driving with **Adversarial Theory of Mind (ToM)** modeling. This project implements a minimax-based learning strategy that simulates adversarial agents capable of perturbing belief inference, enhancing safety and robustness in mixed-intent traffic environments.

## 🔧 Key Features
- **ToM-RL Agent**: Learns to infer the latent intentions of nearby agents.
- **Adversarial Belief Generator**: Models worst-case deceptive agents via gradient-based or learnable perturbations.
- **Minimax Training**: Alternating optimization of protagonist and adversary agents.
- **Custom HighwayEnv Integration**: Includes wrappers for observation history, reward clipping, and collision detection.

## 📁 Project Structure
```
core/             # Core algorithm modules (policy, belief model, adversary, loss)
envs/             # HighwayEnv wrapper and Gym utilities
training/         # Trainer, replay buffer, logger, rollout tools
scripts/          # Entry scripts for training and evaluation
utils/            # Metrics, seed control, visualization
configs/          # YAML configs (optional)
logs/             # Output logs and CSV metrics
checkpoints/      # Saved models
```

## 🚀 Quick Start
### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Train a policy
```bash
python train.py --episodes 3000 --use_adversary --epsilon 0.1
```

### 3. Evaluate the trained model
```bash
python evaluate.py \
  --policy_path checkpoints/ppo_adv_tom/model.pt \
  --belief_path checkpoints/belief/model.pt \
  --adversary_path checkpoints/adv/model.pt \
  --episodes 20 --render
```

### 4. Visualize results
```bash
python plot_results.py \
  --result_paths "ToM-RL=results/tom.json" "Adv-ToM=results/adv.json"
```

## 📊 Metrics Tracked
- **Reward**
- **Collision Rate**
- **Time-To-Collision (TTC)**
- **Jerk (Comfort)**


```

---
Developed with ❤️ for safe and robust autonomous intelligence.
