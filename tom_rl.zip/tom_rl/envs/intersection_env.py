# intersection_env.py
import gym
import numpy as np
from highway_env.envs import IntersectionEnv

class WrappedIntersectionEnv:
    """
    A wrapper around highway-env's IntersectionEnv to support adversarial ToM-RL setup.

    Provides additional support for retrieving observation history,
    tagging rational/adversarial agents, and formatting inputs for ToM models.
    """

    def __init__(self, config=None):
        self.env = IntersectionEnv()
        if config:
            self.env.configure(config)
        self.env.reset()
        self.history_window = 3
        self.obs_history = []

    def reset(self):
        obs = self.env.reset()
        self.obs_history = [obs for _ in range(self.history_window)]
        return self.get_obs()

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.obs_history.pop(0)
        self.obs_history.append(obs)
        return self.get_obs(), reward, done, info

    def get_obs(self):
        """
        Returns a stacked observation of current and past states.
        """
        return np.concatenate(self.obs_history, axis=-1)

    def render(self, mode="human"):
        self.env.render(mode=mode)

    def close(self):
        self.env.close()

    def seed(self, seed_val):
        self.env.seed(seed_val)
