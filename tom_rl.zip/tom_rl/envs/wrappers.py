# wrappers.py
import gym
import numpy as np

class ObservationHistoryWrapper(gym.ObservationWrapper):
    """
    A Gym wrapper that augments the observation space by stacking recent frames.

    This is useful for ToM-based reasoning that requires state history as input.
    """
    def __init__(self, env, history_length=3):
        super().__init__(env)
        self.history_length = history_length
        self.obs_shape = env.observation_space.shape
        low = np.repeat(env.observation_space.low, history_length, axis=0)
        high = np.repeat(env.observation_space.high, history_length, axis=0)
        self.observation_space = gym.spaces.Box(low=low, high=high, dtype=np.float32)
        self.obs_buffer = [np.zeros(self.obs_shape, dtype=np.float32)] * history_length

    def observation(self, obs):
        self.obs_buffer.pop(0)
        self.obs_buffer.append(obs)
        return np.concatenate(self.obs_buffer, axis=0)

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        self.obs_buffer = [obs.copy() for _ in range(self.history_length)]
        return self.observation(obs)


class RewardClippingWrapper(gym.RewardWrapper):
    """
    Optional wrapper that clips rewards to [-1, 1] to stabilize learning.
    """
    def __init__(self, env):
        super().__init__(env)

    def reward(self, reward):
        return np.clip(reward, -1.0, 1.0)


class DoneOnCollisionWrapper(gym.Wrapper):
    """
    Ends episode early if a collision is detected in info dict.
    """
    def __init__(self, env):
        super().__init__(env)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        if info.get("crashed", False):
            done = True
        return obs, reward, done, info
