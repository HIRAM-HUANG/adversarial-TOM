# train.py
import argparse
from training.trainer import train_adversarial_tom
from envs.intersection_env import WrappedIntersectionEnv
from envs.wrappers import ObservationHistoryWrapper, RewardClippingWrapper, DoneOnCollisionWrapper


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--episodes', type=int, default=5000)
    parser.add_argument('--max_steps', type=int, default=200)
    parser.add_argument('--epsilon', type=float, default=0.1)
    parser.add_argument('--use_adversary', action='store_true')
    parser.add_argument('--log_interval', type=int, default=10)
    args = parser.parse_args()

    env = WrappedIntersectionEnv()
    env = ObservationHistoryWrapper(env, history_length=3)
    env = RewardClippingWrapper(env)
    env = DoneOnCollisionWrapper(env)

    obs_dim = env.reset().shape[0]
    action_dim = env.env.action_space.shape[0]
    belief_dim = 32

    train_adversarial_tom(
        env,
        obs_dim=obs_dim,
        belief_dim=belief_dim,
        action_dim=action_dim,
        episodes=args.episodes,
        max_steps=args.max_steps,
        epsilon=args.epsilon,
        use_learned_adversary=args.use_adversary,
        log_interval=args.log_interval
    )


if __name__ == '__main__':
    main()
