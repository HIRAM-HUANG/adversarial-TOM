# evaluate.py
import torch
import numpy as np
from tqdm import tqdm
from core.policy import PolicyNetwork
from core.belief_model import BeliefModel
from core.adversary import AdversarialGenerator
from envs.intersection_env import WrappedIntersectionEnv

def evaluate_policy(policy_path, belief_path=None, adversary_path=None,
                    num_episodes=20, render=False, epsilon=0.0):
    """
    Evaluate a trained policy on the wrapped intersection environment.

    Args:
        policy_path (str): Path to trained policy model.
        belief_path (str): Path to belief model.
        adversary_path (str): Optional path to adversarial generator.
        num_episodes (int): Number of episodes to evaluate.
        render (bool): Whether to render the environment.
        epsilon (float): Perturbation magnitude (used only if no adversary model).

    Returns:
        dict: Evaluation metrics including avg_reward, collision_rate, avg_ttc, avg_jerk
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    env = WrappedIntersectionEnv()
    obs_dim = env.reset().shape[0]
    action_dim = env.env.action_space.shape[0]
    belief_dim = 32

    policy = PolicyNetwork(obs_dim, belief_dim, action_dim).to(device)
    policy.load_state_dict(torch.load(policy_path, map_location=device))
    policy.eval()

    belief_model = BeliefModel(obs_dim, belief_dim).to(device)
    if belief_path:
        belief_model.load_state_dict(torch.load(belief_path, map_location=device))
    belief_model.eval()

    adversary = None
    if adversary_path:
        adversary = AdversarialGenerator(obs_dim, belief_dim).to(device)
        adversary.load_state_dict(torch.load(adversary_path, map_location=device))
        adversary.eval()

    total_rewards, total_collisions, total_ttc, total_jerk = [], 0, [], []

    for _ in tqdm(range(num_episodes)):
        obs = env.reset()
        done = False
        ep_reward, ep_ttc, ep_jerk = 0, [], []

        while not done:
            obs_tensor = torch.FloatTensor(obs).unsqueeze(0).to(device)
            belief = belief_model(obs_tensor)

            if adversary:
                adv_belief = adversary(obs_tensor)
            else:
                adv_belief = belief + epsilon * torch.randn_like(belief)

            action = policy(obs_tensor, adv_belief).squeeze().detach().cpu().numpy()
            obs, reward, done, info = env.step(action)

            ep_reward += reward
            if 'ttc' in info: ep_ttc.append(info['ttc'])
            if 'jerk' in info: ep_jerk.append(info['jerk'])
            if info.get("crashed", False): total_collisions += 1

            if render:
                env.render()

        total_rewards.append(ep_reward)
        total_ttc.append(np.mean(ep_ttc) if ep_ttc else 0.0)
        total_jerk.append(np.mean(ep_jerk) if ep_jerk else 0.0)

    results = {
        "avg_reward": np.mean(total_rewards),
        "collision_rate": total_collisions / num_episodes,
        "avg_ttc": np.mean(total_ttc),
        "avg_jerk": np.mean(total_jerk)
    }
    print("Evaluation Results:", results)
    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy_path", type=str, required=True)
    parser.add_argument("--belief_path", type=str)
    parser.add_argument("--adversary_path", type=str)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--epsilon", type=float, default=0.0)
    args = parser.parse_args()

    evaluate_policy(
        args.policy_path,
        belief_path=args.belief_path,
        adversary_path=args.adversary_path,
        num_episodes=args.episodes,
        render=args.render,
        epsilon=args.epsilon
    )
