# plot_results.py
import matplotlib.pyplot as plt
import numpy as np
import json


def plot_bar_comparison(results_dict, save_path=None):
    """
    Plot bar charts comparing metrics across different methods.

    Args:
        results_dict (dict): Mapping from method name to result metrics.
        save_path (str): Optional path to save the figure.
    """
    methods = list(results_dict.keys())
    metrics = ["collision_rate", "avg_reward", "avg_ttc", "avg_jerk"]
    metric_labels = ["Collision Rate (%)", "Avg Reward", "Min TTC (s)", "Jerk"]

    fig, axes = plt.subplots(1, len(metrics), figsize=(18, 4))
    for i, metric in enumerate(metrics):
        values = [results_dict[m][metric] for m in methods]
        axes[i].bar(methods, values, color='skyblue')
        axes[i].set_title(metric_labels[i])
        axes[i].set_xticks(range(len(methods)))
        axes[i].set_xticklabels(methods, rotation=45, ha='right')
        axes[i].grid(True)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()


def load_results_from_json(paths):
    """
    Load evaluation results stored in JSON files.

    Args:
        paths (dict): Mapping from method name to JSON file path.

    Returns:
        dict: Mapping from method name to result metrics.
    """
    results = {}
    for name, path in paths.items():
        with open(path, 'r') as f:
            results[name] = json.load(f)
    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--result_paths", nargs='+', help="List of method_name=path.json")
    parser.add_argument("--save_path", type=str, default=None)
    args = parser.parse_args()

    paths = {}
    for p in args.result_paths:
        name, file = p.split("=")
        paths[name] = file

    results = load_results_from_json(paths)
    plot_bar_comparison(results, save_path=args.save_path)