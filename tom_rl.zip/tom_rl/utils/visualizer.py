# visualizer.py
import matplotlib.pyplot as plt
import numpy as np


def plot_trajectory(states, actions, save_path=None):
    """
    Plot vehicle trajectory based on recorded states and actions.

    Args:
        states (list): List of [x, y] positions.
        actions (list): List of action vectors.
        save_path (str): Optional path to save the plot.
    """
    states = np.array(states)
    actions = np.array(actions)

    plt.figure(figsize=(8, 6))
    plt.plot(states[:, 0], states[:, 1], '-o', label="Trajectory", color='blue')
    plt.quiver(
        states[:-1, 0], states[:-1, 1],
        actions[:-1, 0], actions[:-1, 1],
        angles='xy', scale_units='xy', scale=1.0, width=0.005, color='red', label="Actions"
    )
    plt.xlabel("X position")
    plt.ylabel("Y position")
    plt.title("Agent Trajectory with Action Vectors")
    plt.legend()
    plt.grid(True)

    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()


def plot_metric_curve(values, title="Metric Over Time", ylabel="Value", save_path=None):
    """
    Plot a single metric over time (e.g., reward, TTC).

    Args:
        values (list or np.array): Metric values.
        title (str): Plot title.
        ylabel (str): Y-axis label.
        save_path (str): Optional path to save the plot.
    """
    plt.figure(figsize=(8, 4))
    plt.plot(values, label=ylabel, color='green')
    plt.xlabel("Episode")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.legend()

    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()
