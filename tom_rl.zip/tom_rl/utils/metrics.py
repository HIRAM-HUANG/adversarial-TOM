# metrics.py
import numpy as np

def compute_ttc(ego_speed, rel_distance, epsilon=1e-5):
    """
    Estimate Time-To-Collision (TTC).

    Args:
        ego_speed (float): Speed of the ego vehicle (m/s).
        rel_distance (float): Relative distance to the front vehicle (m).
        epsilon (float): Small value to prevent division by zero.

    Returns:
        float: Estimated TTC in seconds.
    """
    if ego_speed <= epsilon:
        return float('inf')
    return rel_distance / (ego_speed + epsilon)


def compute_jerk(accelerations):
    """
    Estimate mean squared jerk from acceleration sequence.

    Args:
        accelerations (list or np.array): List of acceleration values.

    Returns:
        float: Mean squared jerk.
    """
    accelerations = np.asarray(accelerations)
    jerks = np.diff(accelerations)
    return np.mean(jerks ** 2) if len(jerks) > 0 else 0.0


def normalize_metric(x, min_val, max_val):
    """
    Normalize a metric to [0, 1] range for comparison or reward shaping.

    Args:
        x (float): Raw metric value.
        min_val (float): Minimum expected value.
        max_val (float): Maximum expected value.

    Returns:
        float: Normalized value in [0, 1].
    """
    return np.clip((x - min_val) / (max_val - min_val + 1e-8), 0, 1)
