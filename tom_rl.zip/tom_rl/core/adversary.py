# adversary.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class AdversarialGenerator(nn.Module):
    """
    Adversarial belief generator module.

    This module outputs adversarially generated belief embeddings from observations,
    designed to mislead the policy network during robust training.

    Args:
        obs_dim (int): Dimension of the observation vector.
        belief_dim (int): Output dimension of the belief vector.
        hidden_size (int): Number of hidden units in each layer.

    Returns:
        torch.Tensor: Adversarial belief vector.
    """
    def __init__(self, obs_dim, belief_dim, hidden_size=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, belief_dim)
        )

    def forward(self, obs):
        return self.net(obs)


def gradient_attack(risk_fn, policy_net, obs, belief, epsilon):
    """
    Perform a gradient-based adversarial attack by perturbing the belief input to increase risk.

    Args:
        risk_fn (Callable): A differentiable function measuring the risk given an action.
        policy_net (nn.Module): Policy network that outputs actions given obs and belief.
        obs (torch.Tensor): Current observation tensor (B, obs_dim).
        belief (torch.Tensor): Belief tensor to be perturbed (B, belief_dim).
        epsilon (float): L-infinity norm constraint on perturbation magnitude.

    Returns:
        torch.Tensor: Perturbed belief tensor of shape (B, belief_dim).
    """
    belief = belief.clone().detach().requires_grad_(True)
    action = policy_net(obs, belief)
    risk = risk_fn(action)
    risk.backward()
    perturbation = epsilon * belief.grad.sign()
    return (belief + perturbation).detach()
