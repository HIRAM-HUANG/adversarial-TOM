# loss.py
import torch

def risk_loss(action, state, target_metrics=None):
    """
    Compute the risk-aware loss combining safety and comfort metrics.

    Args:
        action (torch.Tensor): Output action from policy, shape (B, action_dim).
        state (torch.Tensor): Current state input, shape (B, state_dim).
        target_metrics (dict, optional): Placeholder for extensible metrics like TTC, jerk, etc.

    Returns:
        torch.Tensor: Scalar loss representing combined risk.
    """
    # Example composite loss (can be extended):
    ttc_loss = (state[:, 0] - action[:, 0]) ** 2  # surrogate for time-to-collision
    jerk_loss = (state[:, 1] - action[:, 1]) ** 2  # surrogate for passenger comfort
    return (ttc_loss + jerk_loss).mean()


def compute_loss(policy, belief, obs, risk_fn):
    """
    Wrapper to compute policy loss under given belief and risk formulation.

    Args:
        policy (nn.Module): Policy network taking obs and belief.
        belief (torch.Tensor): Inferred or adversarial belief input.
        obs (torch.Tensor): Current observation.
        risk_fn (Callable): Function to compute risk-aware loss.

    Returns:
        torch.Tensor: Scalar policy loss.
    """
    action = policy(obs, belief)
    return risk_fn(action, obs)
