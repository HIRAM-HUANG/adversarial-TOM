# belief_model.py
import torch
import torch.nn as nn

class BeliefModel(nn.Module):
    """
    Belief model that infers latent intentions from observed state history.

    This model maps observation history to a latent belief vector, representing the
    estimated intentions or mental state of surrounding agents.

    Args:
        input_dim (int): Dimension of the observation history vector.
        belief_dim (int): Output dimension of the inferred belief.
        hidden_size (int): Size of the hidden layers.

    Returns:
        torch.Tensor: Inferred belief embedding.
    """
    def __init__(self, input_dim, belief_dim, hidden_size=128):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, belief_dim)
        )

    def forward(self, obs_history):
        return self.encoder(obs_history)