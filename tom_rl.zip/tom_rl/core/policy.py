# policy.py
import torch
import torch.nn as nn

class PolicyNetwork(nn.Module):
    """
    Policy network that outputs actions conditioned on observation and belief.

    This network implements πθ(at | st, bt), where the action is chosen based
    on the current state and the inferred belief about other agents.

    Args:
        obs_dim (int): Dimension of the observation vector.
        belief_dim (int): Dimension of the inferred belief vector.
        action_dim (int): Dimension of the action output.
        hidden_size (int): Number of hidden units in each layer.

    Returns:
        torch.Tensor: Predicted action vector.
    """
    def __init__(self, obs_dim, belief_dim, action_dim, hidden_size=128):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(obs_dim + belief_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, action_dim)
        )

    def forward(self, obs, belief):
        """
        Forward pass of the policy network.

        Args:
            obs (torch.Tensor): Observation tensor of shape (B, obs_dim).
            belief (torch.Tensor): Belief tensor of shape (B, belief_dim).

        Returns:
            torch.Tensor: Action output of shape (B, action_dim).
        """
        x = torch.cat([obs, belief], dim=-1)
        return self.fc(x)
