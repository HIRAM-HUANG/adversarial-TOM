# logger.py
import os
import csv
import time
from datetime import datetime

class CSVLogger:
    """
    A simple CSV logger to record training metrics.
    Each log file is stored under a timestamped directory.
    """
    def __init__(self, log_dir="logs", filename="train_metrics.csv"):
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_path = os.path.join(log_dir, self.timestamp)
        os.makedirs(self.log_path, exist_ok=True)
        self.filepath = os.path.join(self.log_path, filename)

        self.columns = ["episode", "reward", "collision", "min_ttc", "jerk"]
        with open(self.filepath, mode='w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(self.columns)

    def log(self, episode, reward, collision, min_ttc, jerk):
        row = [episode, reward, collision, min_ttc, jerk]
        with open(self.filepath, mode='a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(row)

    def get_log_path(self):
        return self.filepath
