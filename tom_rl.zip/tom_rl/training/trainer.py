# trainer.py
import torch
import torch.nn as nn
import torch.optim as optim
from core.policy import PolicyNetwork
from core.belief_model import BeliefModel
from core.adversary import AdversarialGenerator, gradient_attack
from core.loss import risk_loss
from training.buffer import ReplayBuffer
from training.logger import CSVLogger


def train_adversarial_tom(
    env,
    obs_dim,
    belief_dim,
    action_dim,
    episodes=1000,
    max_steps=200,
    epsilon=0.1,
    use_learned_adversary=True,
    log_interval=10
):
    """
    Train the Adversarial ToM-RL framework.

    This includes belief inference, adversarial perturbation, and robust policy optimization.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    policy = PolicyNetwork(obs_dim, belief_dim, action_dim).to(device)
    belief_model = BeliefModel(obs_dim, belief_dim).to(device)
    adversary = AdversarialGenerator(obs_dim, belief_dim).to(device) if use_learned_adversary else None

    policy_optim = optim.Adam(policy.parameters(), lr=3e-4)
    adv_optim = optim.Adam(adversary.parameters(), lr=3e-4) if use_learned_adversary else None

    buffer = ReplayBuffer()
    logger = CSVLogger()

    for episode in range(episodes):
        obs = env.reset()
        episode_reward = 0
        crashed = False
        min_ttc = float('inf')
        jerk_values = []

        for step in range(max_steps):
            obs_tensor = torch.FloatTensor(obs).unsqueeze(0).to(device)
            belief = belief_model(obs_tensor)

            if use_learned_adversary:
                adv_belief = adversary(obs_tensor)
            else:
                adv_belief = gradient_attack(
                    lambda a: risk_loss(a, obs_tensor),
                    policy,
                    obs_tensor,
                    belief,
                    epsilon
                )

            action = policy(obs_tensor, adv_belief).detach().cpu().numpy()[0]
            obs_next, reward, done, info = env.step(action)

            buffer.add(obs, adv_belief.cpu().numpy(), action, reward, obs_next, done)
            obs = obs_next
            episode_reward += reward

            if info.get("crashed", False):
                crashed = True
            if 'ttc' in info:
                min_ttc = min(min_ttc, info['ttc'])
            if 'jerk' in info:
                jerk_values.append(info['jerk'])

            if done:
                break

        if len(buffer) > 64:
            for _ in range(10):
                batch = buffer.sample(64)
                obs_batch = torch.FloatTensor(batch['obs']).to(device)
                belief_batch = torch.FloatTensor(batch['belief']).to(device)
                action_batch = torch.FloatTensor(batch['action']).to(device)
                next_obs_batch = torch.FloatTensor(batch['next_obs']).to(device)

                if use_learned_adversary:
                    adv_optim.zero_grad()
                    fake_belief = adversary(obs_batch)
                    adv_loss = risk_loss(policy(obs_batch, fake_belief), obs_batch)
                    adv_loss.backward()
                    adv_optim.step()

                policy_optim.zero_grad()
                use_belief = adversary(obs_batch) if use_learned_adversary else belief_batch
                loss = risk_loss(policy(obs_batch, use_belief), obs_batch)
                loss.backward()
                policy_optim.step()

        avg_jerk = sum(jerk_values) / len(jerk_values) if jerk_values else 0.0
        logger.log(episode, episode_reward, int(crashed), min_ttc, avg_jerk)

        if episode % log_interval == 0:
            print(f"Episode {episode}, Reward: {episode_reward:.2f}, Crash: {crashed}, TTC: {min_ttc:.2f}, Jerk: {avg_jerk:.3f}")
