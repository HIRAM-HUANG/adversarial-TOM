# rollout.py
import torch
import numpy as np
from core.policy import PolicyNetwork
from core.belief_model import BeliefModel
from core.adversary import AdversarialGenerator


def rollout_episode(env, policy, belief_model, adversary=None, epsilon=0.0, device="cpu", render=False):
    """
    Run a single rollout episode in the environment.

    Args:
        env: the environment object.
        policy: trained policy network.
        belief_model: learned belief model.
        adversary: optional adversarial generator.
        epsilon: magnitude of random noise if no adversary.
        device: computation device.
        render: whether to render the rollout.

    Returns:
        dict: containing reward, collision flag, avg TTC, avg jerk
    """
    obs = env.reset()
    done = False
    total_reward = 0
    crashed = False
    ttc_list, jerk_list = [], []

    while not done:
        obs_tensor = torch.FloatTensor(obs).unsqueeze(0).to(device)
        belief = belief_model(obs_tensor)

        if adversary:
            adv_belief = adversary(obs_tensor)
        else:
            adv_belief = belief + epsilon * torch.randn_like(belief)

        with torch.no_grad():
            action = policy(obs_tensor, adv_belief).squeeze().cpu().numpy()

        obs, reward, done, info = env.step(action)
        total_reward += reward

        if info.get("crashed", False):
            crashed = True
        if 'ttc' in info:
            ttc_list.append(info['ttc'])
        if 'jerk' in info:
            jerk_list.append(info['jerk'])

        if render:
            env.render()

    return {
        "reward": total_reward,
        "collision": int(crashed),
        "min_ttc": np.min(ttc_list) if ttc_list else 0.0,
        "jerk": np.mean(jerk_list) if jerk_list else 0.0
    }
