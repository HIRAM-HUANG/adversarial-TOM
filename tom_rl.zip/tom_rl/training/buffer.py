# buffer.py
import random
import numpy as np

class ReplayBuffer:
    """
    A simple replay buffer for storing transitions.
    Stores: (obs, belief, action, reward, next_obs, done)
    """
    def __init__(self, max_size=100000):
        self.max_size = max_size
        self.storage = []
        self.ptr = 0

    def add(self, obs, belief, action, reward, next_obs, done):
        data = (obs, belief, action, reward, next_obs, done)
        if len(self.storage) < self.max_size:
            self.storage.append(data)
        else:
            self.storage[self.ptr] = data
            self.ptr = (self.ptr + 1) % self.max_size

    def sample(self, batch_size):
        batch = random.sample(self.storage, batch_size)
        obs, belief, action, reward, next_obs, done = map(np.stack, zip(*batch))
        return {
            'obs': obs,
            'belief': belief,
            'action': action,
            'reward': reward,
            'next_obs': next_obs,
            'done': done
        }

    def __len__(self):
        return len(self.storage)
